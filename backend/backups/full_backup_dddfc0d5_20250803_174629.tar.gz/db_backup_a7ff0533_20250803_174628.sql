--
-- PostgreSQL database dump
--

-- Dumped from database version 14.18 (Homebrew)
-- Dumped by pg_dump version 14.18 (Homebrew)

-- Started on 2025-08-03 13:46:28 EDT

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE my_rust_cms;
--
-- TOC entry 3895 (class 1262 OID 16385)
-- Name: my_rust_cms; Type: DATABASE; Schema: -; Owner: burtron
--

CREATE DATABASE my_rust_cms WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C';


ALTER DATABASE my_rust_cms OWNER TO burtron;

\connect my_rust_cms

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 2 (class 3079 OID 24875)
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- TOC entry 3897 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- TOC entry 279 (class 1255 OID 25148)
-- Name: diesel_manage_updated_at(regclass); Type: FUNCTION; Schema: public; Owner: riverwalkit
--

CREATE FUNCTION public.diesel_manage_updated_at(_tbl regclass) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    EXECUTE format('CREATE TRIGGER set_updated_at BEFORE UPDATE ON %s
                    FOR EACH ROW EXECUTE PROCEDURE diesel_set_updated_at()', _tbl);
END;
$$;


ALTER FUNCTION public.diesel_manage_updated_at(_tbl regclass) OWNER TO riverwalkit;

--
-- TOC entry 280 (class 1255 OID 25149)
-- Name: diesel_set_updated_at(); Type: FUNCTION; Schema: public; Owner: riverwalkit
--

CREATE FUNCTION public.diesel_set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF (
        NEW IS DISTINCT FROM OLD AND
        NEW.updated_at IS NOT DISTINCT FROM OLD.updated_at
    ) THEN
        NEW.updated_at := current_timestamp;
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.diesel_set_updated_at() OWNER TO riverwalkit;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 210 (class 1259 OID 16386)
-- Name: __diesel_schema_migrations; Type: TABLE; Schema: public; Owner: riverwalkit
--

CREATE TABLE public.__diesel_schema_migrations (
    version character varying(50) NOT NULL,
    run_on timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.__diesel_schema_migrations OWNER TO riverwalkit;

--
-- TOC entry 224 (class 1259 OID 24733)
-- Name: builder_components; Type: TABLE; Schema: public; Owner: riverwalkit
--

CREATE TABLE public.builder_components (
    id integer NOT NULL,
    component_name character varying NOT NULL,
    component_data jsonb,
    template_id integer,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone
);


ALTER TABLE public.builder_components OWNER TO riverwalkit;

--
-- TOC entry 223 (class 1259 OID 24732)
-- Name: builder_components_id_seq; Type: SEQUENCE; Schema: public; Owner: riverwalkit
--

CREATE SEQUENCE public.builder_components_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.builder_components_id_seq OWNER TO riverwalkit;

--
-- TOC entry 3898 (class 0 OID 0)
-- Dependencies: 223
-- Name: builder_components_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: riverwalkit
--

ALTER SEQUENCE public.builder_components_id_seq OWNED BY public.builder_components.id;


--
-- TOC entry 214 (class 1259 OID 24661)
-- Name: categories; Type: TABLE; Schema: public; Owner: riverwalkit
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.categories OWNER TO riverwalkit;

--
-- TOC entry 213 (class 1259 OID 24660)
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: riverwalkit
--

CREATE SEQUENCE public.categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categories_id_seq OWNER TO riverwalkit;

--
-- TOC entry 3899 (class 0 OID 0)
-- Dependencies: 213
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: riverwalkit
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- TOC entry 228 (class 1259 OID 24760)
-- Name: comments; Type: TABLE; Schema: public; Owner: riverwalkit
--

CREATE TABLE public.comments (
    id integer NOT NULL,
    post_id integer,
    user_id integer,
    content text NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone
);


ALTER TABLE public.comments OWNER TO riverwalkit;

--
-- TOC entry 227 (class 1259 OID 24759)
-- Name: comments_id_seq; Type: SEQUENCE; Schema: public; Owner: riverwalkit
--

CREATE SEQUENCE public.comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.comments_id_seq OWNER TO riverwalkit;

--
-- TOC entry 3900 (class 0 OID 0)
-- Dependencies: 227
-- Name: comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: riverwalkit
--

ALTER SEQUENCE public.comments_id_seq OWNED BY public.comments.id;


--
-- TOC entry 240 (class 1259 OID 24860)
-- Name: component_events; Type: TABLE; Schema: public; Owner: riverwalkit
--

CREATE TABLE public.component_events (
    id integer NOT NULL,
    component_id integer,
    event_type character varying NOT NULL,
    event_handler text NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.component_events OWNER TO riverwalkit;

--
-- TOC entry 239 (class 1259 OID 24859)
-- Name: component_events_id_seq; Type: SEQUENCE; Schema: public; Owner: riverwalkit
--

CREATE SEQUENCE public.component_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.component_events_id_seq OWNER TO riverwalkit;

--
-- TOC entry 3901 (class 0 OID 0)
-- Dependencies: 239
-- Name: component_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: riverwalkit
--

ALTER SEQUENCE public.component_events_id_seq OWNED BY public.component_events.id;


--
-- TOC entry 238 (class 1259 OID 24845)
-- Name: component_styles; Type: TABLE; Schema: public; Owner: riverwalkit
--

CREATE TABLE public.component_styles (
    id integer NOT NULL,
    component_id integer,
    css text NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone
);


ALTER TABLE public.component_styles OWNER TO riverwalkit;

--
-- TOC entry 237 (class 1259 OID 24844)
-- Name: component_styles_id_seq; Type: SEQUENCE; Schema: public; Owner: riverwalkit
--

CREATE SEQUENCE public.component_styles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.component_styles_id_seq OWNER TO riverwalkit;

--
-- TOC entry 3902 (class 0 OID 0)
-- Dependencies: 237
-- Name: component_styles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: riverwalkit
--

ALTER SEQUENCE public.component_styles_id_seq OWNED BY public.component_styles.id;


--
-- TOC entry 234 (class 1259 OID 24812)
-- Name: components; Type: TABLE; Schema: public; Owner: riverwalkit
--

CREATE TABLE public.components (
    id integer NOT NULL,
    name character varying NOT NULL,
    template_id integer,
    component_data jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone
);


ALTER TABLE public.components OWNER TO riverwalkit;

--
-- TOC entry 233 (class 1259 OID 24811)
-- Name: components_id_seq; Type: SEQUENCE; Schema: public; Owner: riverwalkit
--

CREATE SEQUENCE public.components_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.components_id_seq OWNER TO riverwalkit;

--
-- TOC entry 3903 (class 0 OID 0)
-- Dependencies: 233
-- Name: components_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: riverwalkit
--

ALTER SEQUENCE public.components_id_seq OWNED BY public.components.id;


--
-- TOC entry 220 (class 1259 OID 24705)
-- Name: media; Type: TABLE; Schema: public; Owner: riverwalkit
--

CREATE TABLE public.media (
    id integer NOT NULL,
    file_name character varying NOT NULL,
    url character varying NOT NULL,
    media_type character varying,
    uploaded_at timestamp without time zone DEFAULT now(),
    user_id integer
);


ALTER TABLE public.media OWNER TO riverwalkit;

--
-- TOC entry 219 (class 1259 OID 24704)
-- Name: media_id_seq; Type: SEQUENCE; Schema: public; Owner: riverwalkit
--

CREATE SEQUENCE public.media_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.media_id_seq OWNER TO riverwalkit;

--
-- TOC entry 3904 (class 0 OID 0)
-- Dependencies: 219
-- Name: media_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: riverwalkit
--

ALTER SEQUENCE public.media_id_seq OWNED BY public.media.id;


--
-- TOC entry 242 (class 1259 OID 25173)
-- Name: navigation; Type: TABLE; Schema: public; Owner: username
--

CREATE TABLE public.navigation (
    id integer NOT NULL,
    title character varying NOT NULL,
    url character varying NOT NULL,
    order_position integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.navigation OWNER TO username;

--
-- TOC entry 241 (class 1259 OID 25172)
-- Name: navigation_id_seq; Type: SEQUENCE; Schema: public; Owner: username
--

CREATE SEQUENCE public.navigation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.navigation_id_seq OWNER TO username;

--
-- TOC entry 3905 (class 0 OID 0)
-- Dependencies: 241
-- Name: navigation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: username
--

ALTER SEQUENCE public.navigation_id_seq OWNED BY public.navigation.id;


--
-- TOC entry 236 (class 1259 OID 24827)
-- Name: page_components; Type: TABLE; Schema: public; Owner: riverwalkit
--

CREATE TABLE public.page_components (
    id integer NOT NULL,
    page_id integer,
    component_id integer,
    "position" integer NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.page_components OWNER TO riverwalkit;

--
-- TOC entry 235 (class 1259 OID 24826)
-- Name: page_components_id_seq; Type: SEQUENCE; Schema: public; Owner: riverwalkit
--

CREATE SEQUENCE public.page_components_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.page_components_id_seq OWNER TO riverwalkit;

--
-- TOC entry 3906 (class 0 OID 0)
-- Dependencies: 235
-- Name: page_components_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: riverwalkit
--

ALTER SEQUENCE public.page_components_id_seq OWNED BY public.page_components.id;


--
-- TOC entry 232 (class 1259 OID 24797)
-- Name: page_sections; Type: TABLE; Schema: public; Owner: riverwalkit
--

CREATE TABLE public.page_sections (
    id integer NOT NULL,
    page_id integer,
    section_name character varying NOT NULL,
    content text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone
);


ALTER TABLE public.page_sections OWNER TO riverwalkit;

--
-- TOC entry 231 (class 1259 OID 24796)
-- Name: page_sections_id_seq; Type: SEQUENCE; Schema: public; Owner: riverwalkit
--

CREATE SEQUENCE public.page_sections_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.page_sections_id_seq OWNER TO riverwalkit;

--
-- TOC entry 3907 (class 0 OID 0)
-- Dependencies: 231
-- Name: page_sections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: riverwalkit
--

ALTER SEQUENCE public.page_sections_id_seq OWNED BY public.page_sections.id;


--
-- TOC entry 218 (class 1259 OID 24690)
-- Name: pages; Type: TABLE; Schema: public; Owner: riverwalkit
--

CREATE TABLE public.pages (
    id integer NOT NULL,
    title character varying NOT NULL,
    content text NOT NULL,
    user_id integer,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone,
    slug character varying NOT NULL,
    status character varying DEFAULT 'draft'::character varying NOT NULL
);


ALTER TABLE public.pages OWNER TO riverwalkit;

--
-- TOC entry 217 (class 1259 OID 24689)
-- Name: pages_id_seq; Type: SEQUENCE; Schema: public; Owner: riverwalkit
--

CREATE SEQUENCE public.pages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pages_id_seq OWNER TO riverwalkit;

--
-- TOC entry 3908 (class 0 OID 0)
-- Dependencies: 217
-- Name: pages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: riverwalkit
--

ALTER SEQUENCE public.pages_id_seq OWNED BY public.pages.id;


--
-- TOC entry 216 (class 1259 OID 24670)
-- Name: posts; Type: TABLE; Schema: public; Owner: riverwalkit
--

CREATE TABLE public.posts (
    id integer NOT NULL,
    title character varying NOT NULL,
    content text NOT NULL,
    category_id integer,
    user_id integer,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone
);


ALTER TABLE public.posts OWNER TO riverwalkit;

--
-- TOC entry 215 (class 1259 OID 24669)
-- Name: posts_id_seq; Type: SEQUENCE; Schema: public; Owner: riverwalkit
--

CREATE SEQUENCE public.posts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.posts_id_seq OWNER TO riverwalkit;

--
-- TOC entry 3909 (class 0 OID 0)
-- Dependencies: 215
-- Name: posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: riverwalkit
--

ALTER SEQUENCE public.posts_id_seq OWNED BY public.posts.id;


--
-- TOC entry 230 (class 1259 OID 24780)
-- Name: sessions; Type: TABLE; Schema: public; Owner: riverwalkit
--

CREATE TABLE public.sessions (
    id integer NOT NULL,
    user_id integer,
    session_token character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    expires_at timestamp without time zone
);


ALTER TABLE public.sessions OWNER TO riverwalkit;

--
-- TOC entry 229 (class 1259 OID 24779)
-- Name: sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: riverwalkit
--

CREATE SEQUENCE public.sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sessions_id_seq OWNER TO riverwalkit;

--
-- TOC entry 3910 (class 0 OID 0)
-- Dependencies: 229
-- Name: sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: riverwalkit
--

ALTER SEQUENCE public.sessions_id_seq OWNED BY public.sessions.id;


--
-- TOC entry 226 (class 1259 OID 24748)
-- Name: settings; Type: TABLE; Schema: public; Owner: riverwalkit
--

CREATE TABLE public.settings (
    id integer NOT NULL,
    setting_key character varying NOT NULL,
    setting_value text,
    created_at timestamp without time zone DEFAULT now(),
    setting_type character varying DEFAULT 'system'::character varying NOT NULL,
    description text,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.settings OWNER TO riverwalkit;

--
-- TOC entry 225 (class 1259 OID 24747)
-- Name: settings_id_seq; Type: SEQUENCE; Schema: public; Owner: riverwalkit
--

CREATE SEQUENCE public.settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.settings_id_seq OWNER TO riverwalkit;

--
-- TOC entry 3911 (class 0 OID 0)
-- Dependencies: 225
-- Name: settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: riverwalkit
--

ALTER SEQUENCE public.settings_id_seq OWNED BY public.settings.id;


--
-- TOC entry 222 (class 1259 OID 24721)
-- Name: templates; Type: TABLE; Schema: public; Owner: riverwalkit
--

CREATE TABLE public.templates (
    id integer NOT NULL,
    name character varying NOT NULL,
    layout text NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone
);


ALTER TABLE public.templates OWNER TO riverwalkit;

--
-- TOC entry 221 (class 1259 OID 24720)
-- Name: templates_id_seq; Type: SEQUENCE; Schema: public; Owner: riverwalkit
--

CREATE SEQUENCE public.templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.templates_id_seq OWNER TO riverwalkit;

--
-- TOC entry 3912 (class 0 OID 0)
-- Dependencies: 221
-- Name: templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: riverwalkit
--

ALTER SEQUENCE public.templates_id_seq OWNED BY public.templates.id;


--
-- TOC entry 212 (class 1259 OID 24577)
-- Name: users; Type: TABLE; Schema: public; Owner: riverwalkit
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying NOT NULL,
    password character varying NOT NULL,
    email character varying,
    created_at timestamp without time zone DEFAULT now(),
    role character varying DEFAULT 'user'::character varying NOT NULL,
    status character varying DEFAULT 'active'::character varying NOT NULL
);


ALTER TABLE public.users OWNER TO riverwalkit;

--
-- TOC entry 211 (class 1259 OID 24576)
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: riverwalkit
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO riverwalkit;

--
-- TOC entry 3913 (class 0 OID 0)
-- Dependencies: 211
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: riverwalkit
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- TOC entry 3631 (class 2604 OID 24736)
-- Name: builder_components id; Type: DEFAULT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.builder_components ALTER COLUMN id SET DEFAULT nextval('public.builder_components_id_seq'::regclass);


--
-- TOC entry 3621 (class 2604 OID 24664)
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- TOC entry 3637 (class 2604 OID 24763)
-- Name: comments id; Type: DEFAULT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.comments ALTER COLUMN id SET DEFAULT nextval('public.comments_id_seq'::regclass);


--
-- TOC entry 3649 (class 2604 OID 24863)
-- Name: component_events id; Type: DEFAULT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.component_events ALTER COLUMN id SET DEFAULT nextval('public.component_events_id_seq'::regclass);


--
-- TOC entry 3647 (class 2604 OID 24848)
-- Name: component_styles id; Type: DEFAULT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.component_styles ALTER COLUMN id SET DEFAULT nextval('public.component_styles_id_seq'::regclass);


--
-- TOC entry 3643 (class 2604 OID 24815)
-- Name: components id; Type: DEFAULT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.components ALTER COLUMN id SET DEFAULT nextval('public.components_id_seq'::regclass);


--
-- TOC entry 3627 (class 2604 OID 24708)
-- Name: media id; Type: DEFAULT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.media ALTER COLUMN id SET DEFAULT nextval('public.media_id_seq'::regclass);


--
-- TOC entry 3651 (class 2604 OID 25176)
-- Name: navigation id; Type: DEFAULT; Schema: public; Owner: username
--

ALTER TABLE ONLY public.navigation ALTER COLUMN id SET DEFAULT nextval('public.navigation_id_seq'::regclass);


--
-- TOC entry 3645 (class 2604 OID 24830)
-- Name: page_components id; Type: DEFAULT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.page_components ALTER COLUMN id SET DEFAULT nextval('public.page_components_id_seq'::regclass);


--
-- TOC entry 3641 (class 2604 OID 24800)
-- Name: page_sections id; Type: DEFAULT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.page_sections ALTER COLUMN id SET DEFAULT nextval('public.page_sections_id_seq'::regclass);


--
-- TOC entry 3624 (class 2604 OID 24693)
-- Name: pages id; Type: DEFAULT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.pages ALTER COLUMN id SET DEFAULT nextval('public.pages_id_seq'::regclass);


--
-- TOC entry 3622 (class 2604 OID 24673)
-- Name: posts id; Type: DEFAULT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.posts ALTER COLUMN id SET DEFAULT nextval('public.posts_id_seq'::regclass);


--
-- TOC entry 3639 (class 2604 OID 24783)
-- Name: sessions id; Type: DEFAULT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.sessions ALTER COLUMN id SET DEFAULT nextval('public.sessions_id_seq'::regclass);


--
-- TOC entry 3633 (class 2604 OID 24751)
-- Name: settings id; Type: DEFAULT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.settings ALTER COLUMN id SET DEFAULT nextval('public.settings_id_seq'::regclass);


--
-- TOC entry 3629 (class 2604 OID 24724)
-- Name: templates id; Type: DEFAULT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.templates ALTER COLUMN id SET DEFAULT nextval('public.templates_id_seq'::regclass);


--
-- TOC entry 3617 (class 2604 OID 24580)
-- Name: users id; Type: DEFAULT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- TOC entry 3857 (class 0 OID 16386)
-- Dependencies: 210
-- Data for Name: __diesel_schema_migrations; Type: TABLE DATA; Schema: public; Owner: riverwalkit
--

COPY public.__diesel_schema_migrations (version, run_on) FROM stdin;
20240908203809	2024-09-10 19:53:30.049482
20240908203854	2024-09-12 12:28:38.7814
20240908203924	2024-09-12 12:28:38.795624
20240908203955	2024-09-12 12:28:38.802255
20240908204032	2024-09-12 12:30:19.097835
20240908204043	2024-09-12 12:30:19.099227
20240908204106	2024-09-12 12:30:19.106367
20240908204127	2024-09-12 12:30:19.111808
20240908204535	2024-09-12 12:30:19.119334
20240908204546	2024-09-12 12:30:19.125554
20240908204613	2024-09-12 12:30:19.129231
20240908204655	2024-09-12 12:30:19.135272
20240908204706	2024-09-12 12:30:19.139791
20240908204727	2024-09-12 12:30:19.143128
20240908204810	2024-09-12 12:30:19.146814
00000000000000	2025-07-30 12:39:33.615904
20250731154209	2025-07-31 15:42:26.830724
20250731154806	2025-07-31 15:48:31.014457
20250731223330	2025-08-02 14:20:09.725533
20250802141916	2025-08-02 14:20:09.732598
20250803154135	2025-08-03 15:44:14.33849
\.


--
-- TOC entry 3871 (class 0 OID 24733)
-- Dependencies: 224
-- Data for Name: builder_components; Type: TABLE DATA; Schema: public; Owner: riverwalkit
--

COPY public.builder_components (id, component_name, component_data, template_id, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3861 (class 0 OID 24661)
-- Dependencies: 214
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: riverwalkit
--

COPY public.categories (id, name) FROM stdin;
1	General
\.


--
-- TOC entry 3875 (class 0 OID 24760)
-- Dependencies: 228
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: riverwalkit
--

COPY public.comments (id, post_id, user_id, content, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3887 (class 0 OID 24860)
-- Dependencies: 240
-- Data for Name: component_events; Type: TABLE DATA; Schema: public; Owner: riverwalkit
--

COPY public.component_events (id, component_id, event_type, event_handler, created_at) FROM stdin;
\.


--
-- TOC entry 3885 (class 0 OID 24845)
-- Dependencies: 238
-- Data for Name: component_styles; Type: TABLE DATA; Schema: public; Owner: riverwalkit
--

COPY public.component_styles (id, component_id, css, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3881 (class 0 OID 24812)
-- Dependencies: 234
-- Data for Name: components; Type: TABLE DATA; Schema: public; Owner: riverwalkit
--

COPY public.components (id, name, template_id, component_data, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3867 (class 0 OID 24705)
-- Dependencies: 220
-- Data for Name: media; Type: TABLE DATA; Schema: public; Owner: riverwalkit
--

COPY public.media (id, file_name, url, media_type, uploaded_at, user_id) FROM stdin;
5	test_upload.txt	/uploads/022228d4-ce8c-4af8-9944-18de0bfd7baf.txt	text/plain	2025-08-01 00:38:42.044255	\N
6	test_media.txt	/uploads/58529465-8d16-425d-b38d-3d01d0329ca4.txt	text/plain	2025-08-01 00:46:58.263485	\N
7	test_parse.txt	/uploads/d181e43e-e0cb-4c6b-8fc6-0fe5aaa27ab4.txt	text/plain	2025-08-01 00:52:21.85484	\N
8	JB.jpg	/uploads/52cf8088-525e-47c0-9146-3b9533e34ed3.jpg	image/jpeg	2025-08-01 00:53:27.688054	\N
9	branding-cover-BL.png	/uploads/69635ed8-655c-4460-8417-459bba096433.png	image/png	2025-08-01 01:12:39.949657	\N
\.


--
-- TOC entry 3889 (class 0 OID 25173)
-- Dependencies: 242
-- Data for Name: navigation; Type: TABLE DATA; Schema: public; Owner: username
--

COPY public.navigation (id, title, url, order_position, is_active, created_at, updated_at) FROM stdin;
1	Home	/	1	t	2025-08-02 14:24:18.070069	2025-08-02 14:24:18.070069
2	Posts	/posts	2	t	2025-08-02 14:24:18.071281	2025-08-02 14:24:18.071281
\.


--
-- TOC entry 3883 (class 0 OID 24827)
-- Dependencies: 236
-- Data for Name: page_components; Type: TABLE DATA; Schema: public; Owner: riverwalkit
--

COPY public.page_components (id, page_id, component_id, "position", created_at) FROM stdin;
\.


--
-- TOC entry 3879 (class 0 OID 24797)
-- Dependencies: 232
-- Data for Name: page_sections; Type: TABLE DATA; Schema: public; Owner: riverwalkit
--

COPY public.page_sections (id, page_id, section_name, content, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3865 (class 0 OID 24690)
-- Dependencies: 218
-- Data for Name: pages; Type: TABLE DATA; Schema: public; Owner: riverwalkit
--

COPY public.pages (id, title, content, user_id, created_at, updated_at, slug, status) FROM stdin;
6	Contact Us	Get in touch with us!	2	2025-07-31 22:21:09.393571	\N	contact-us	published
7	Our Services	Check out our amazing services	2	2025-07-31 22:21:09.401845	\N	our-services	published
24	Extraordinary	[{"id":"b3589d6f-9ffd-4ae3-afc6-d96a108e6f11","component_type":"Image","content":"![Rust CMS Dashboard](https://via.placeholder.com/800x400/4299e1/ffffff?text=Rust+CMS+Dashboard)","styles":{"background_color":"transparent","text_color":"inherit","padding":"16px","margin":"8px","border_radius":"8px","font_size":"16px","font_weight":"normal","text_align":"left","border_width":"0px","border_color":"transparent","border_style":"solid","box_shadow":"none","opacity":1.0,"z_index":1,"font_family":"system-ui, -apple-system, sans-serif","line_height":"1.5","letter_spacing":"normal","text_decoration":"none","text_transform":"none","background_image":"none","background_size":"cover","background_position":"center","background_repeat":"no-repeat"},"position":{"x":0.0,"y":0.0,"width":"100%","height":"auto"},"properties":{"image_url":"","image_alt":"","image_title":"","image_lazy_load":true,"button_text":"Click Here","button_url":"#","button_target":"_self","button_size":"medium","button_variant":"primary","button_icon":"","form_action":"","form_method":"POST","form_fields":[],"video_url":"","video_autoplay":false,"video_controls":true,"video_muted":false,"video_loop":false,"gallery_images":[],"gallery_layout":"grid","gallery_columns":3,"list_type":"unordered","list_items":[],"container_max_width":"1200px","container_align":"center","animation_type":"none","animation_duration":"0.3s","animation_delay":"0s","seo_title":"","seo_description":"","seo_keywords":[],"aria_label":"","aria_description":"","tab_index":0}},{"id":"460923dd-d9c4-4a0e-82c9-bfe6855025e7","component_type":"Card","content":"## 🌟 Feature Highlight\\n\\nDrag-and-drop page builder with real-time preview. Create professional pages without coding knowledge.\\n\\n**Key Benefits:**\\n- Visual editing\\n- Real-time preview\\n- Mobile responsive\\n- SEO optimized\\n\\n[Try Page Builder →](/page-builder)","styles":{"background_color":"transparent","text_color":"inherit","padding":"16px","margin":"8px","border_radius":"8px","font_size":"16px","font_weight":"normal","text_align":"left","border_width":"0px","border_color":"transparent","border_style":"solid","box_shadow":"none","opacity":1.0,"z_index":1,"font_family":"system-ui, -apple-system, sans-serif","line_height":"1.5","letter_spacing":"normal","text_decoration":"none","text_transform":"none","background_image":"none","background_size":"cover","background_position":"center","background_repeat":"no-repeat"},"position":{"x":0.0,"y":0.0,"width":"100%","height":"auto"},"properties":{"image_url":"","image_alt":"","image_title":"","image_lazy_load":true,"button_text":"Click Here","button_url":"#","button_target":"_self","button_size":"medium","button_variant":"primary","button_icon":"","form_action":"","form_method":"POST","form_fields":[],"video_url":"","video_autoplay":false,"video_controls":true,"video_muted":false,"video_loop":false,"gallery_images":[],"gallery_layout":"grid","gallery_columns":3,"list_type":"unordered","list_items":[],"container_max_width":"1200px","container_align":"center","animation_type":"none","animation_duration":"0.3s","animation_delay":"0s","seo_title":"","seo_description":"","seo_keywords":[],"aria_label":"","aria_description":"","tab_index":0}},{"id":"af0e6b63-a9ec-494a-909d-2406738e4ed0","component_type":"Hero","content":"# Welcome to the Future of Content Management\\n\\nExperience the power of Rust-based CMS with WebAssembly frontend. Create stunning websites with our drag-and-drop page builder and comprehensive content management tools.\\n\\n[Get Started →](/register) [View Demo →](/demo)","styles":{"background_color":"transparent","text_color":"inherit","padding":"16px","margin":"8px","border_radius":"8px","font_size":"16px","font_weight":"normal","text_align":"left","border_width":"0px","border_color":"transparent","border_style":"solid","box_shadow":"none","opacity":1.0,"z_index":1,"font_family":"system-ui, -apple-system, sans-serif","line_height":"1.5","letter_spacing":"normal","text_decoration":"none","text_transform":"none","background_image":"none","background_size":"cover","background_position":"center","background_repeat":"no-repeat"},"position":{"x":0.0,"y":0.0,"width":"100%","height":"auto"},"properties":{"image_url":"","image_alt":"","image_title":"","image_lazy_load":true,"button_text":"Click Here","button_url":"#","button_target":"_self","button_size":"medium","button_variant":"primary","button_icon":"","form_action":"","form_method":"POST","form_fields":[],"video_url":"","video_autoplay":false,"video_controls":true,"video_muted":false,"video_loop":false,"gallery_images":[],"gallery_layout":"grid","gallery_columns":3,"list_type":"unordered","list_items":[],"container_max_width":"1200px","container_align":"center","animation_type":"none","animation_duration":"0.3s","animation_delay":"0s","seo_title":"","seo_description":"","seo_keywords":[],"aria_label":"","aria_description":"","tab_index":0}},{"id":"c08253be-ca22-4923-b547-e34f8c8476f3","component_type":"Card","content":"## 🌟 Feature Highlight\\n\\nDrag-and-drop page builder with real-time preview. Create professional pages without coding knowledge.\\n\\n**Key Benefits:**\\n- Visual editing\\n- Real-time preview\\n- Mobile responsive\\n- SEO optimized\\n\\n[Try Page Builder →](/page-builder)","styles":{"background_color":"transparent","text_color":"inherit","padding":"16px","margin":"8px","border_radius":"8px","font_size":"16px","font_weight":"normal","text_align":"left","border_width":"0px","border_color":"transparent","border_style":"solid","box_shadow":"none","opacity":1.0,"z_index":1,"font_family":"system-ui, -apple-system, sans-serif","line_height":"1.5","letter_spacing":"normal","text_decoration":"none","text_transform":"none","background_image":"none","background_size":"cover","background_position":"center","background_repeat":"no-repeat"},"position":{"x":0.0,"y":0.0,"width":"100%","height":"auto"},"properties":{"image_url":"","image_alt":"","image_title":"","image_lazy_load":true,"button_text":"Click Here","button_url":"#","button_target":"_self","button_size":"medium","button_variant":"primary","button_icon":"","form_action":"","form_method":"POST","form_fields":[],"video_url":"","video_autoplay":false,"video_controls":true,"video_muted":false,"video_loop":false,"gallery_images":[],"gallery_layout":"grid","gallery_columns":3,"list_type":"unordered","list_items":[],"container_max_width":"1200px","container_align":"center","animation_type":"none","animation_duration":"0.3s","animation_delay":"0s","seo_title":"","seo_description":"","seo_keywords":[],"aria_label":"","aria_description":"","tab_index":0}},{"id":"beddad78-d801-4424-a6fc-3df5fcb595a7","component_type":"List","content":"✅ **Rust-powered backend** for maximum performance\\n✅ **WebAssembly frontend** for modern user experience\\n✅ **Drag-and-drop page builder** for easy content creation\\n✅ **Media management** with file upload and organization\\n✅ **User authentication** and role-based access\\n✅ **Responsive design** that works on all devices","styles":{"background_color":"transparent","text_color":"inherit","padding":"16px","margin":"8px","border_radius":"8px","font_size":"16px","font_weight":"normal","text_align":"left","border_width":"0px","border_color":"transparent","border_style":"solid","box_shadow":"none","opacity":1.0,"z_index":1,"font_family":"system-ui, -apple-system, sans-serif","line_height":"1.5","letter_spacing":"normal","text_decoration":"none","text_transform":"none","background_image":"none","background_size":"cover","background_position":"center","background_repeat":"no-repeat"},"position":{"x":0.0,"y":0.0,"width":"100%","height":"auto"},"properties":{"image_url":"","image_alt":"","image_title":"","image_lazy_load":true,"button_text":"Click Here","button_url":"#","button_target":"_self","button_size":"medium","button_variant":"primary","button_icon":"","form_action":"","form_method":"POST","form_fields":[],"video_url":"","video_autoplay":false,"video_controls":true,"video_muted":false,"video_loop":false,"gallery_images":[],"gallery_layout":"grid","gallery_columns":3,"list_type":"unordered","list_items":[],"container_max_width":"1200px","container_align":"center","animation_type":"none","animation_duration":"0.3s","animation_delay":"0s","seo_title":"","seo_description":"","seo_keywords":[],"aria_label":"","aria_description":"","tab_index":0}},{"id":"94d53893-6100-4364-b82d-54b80debff97","component_type":"Text","content":"Welcome to our comprehensive content management system built with Rust and modern web technologies. This platform provides powerful tools for creating, managing, and publishing content with ease.","styles":{"background_color":"transparent","text_color":"inherit","padding":"16px","margin":"8px","border_radius":"8px","font_size":"16px","font_weight":"normal","text_align":"left","border_width":"0px","border_color":"transparent","border_style":"solid","box_shadow":"none","opacity":1.0,"z_index":1,"font_family":"system-ui, -apple-system, sans-serif","line_height":"1.5","letter_spacing":"normal","text_decoration":"none","text_transform":"none","background_image":"none","background_size":"cover","background_position":"center","background_repeat":"no-repeat"},"position":{"x":0.0,"y":0.0,"width":"100%","height":"auto"},"properties":{"image_url":"","image_alt":"","image_title":"","image_lazy_load":true,"button_text":"Click Here","button_url":"#","button_target":"_self","button_size":"medium","button_variant":"primary","button_icon":"","form_action":"","form_method":"POST","form_fields":[],"video_url":"","video_autoplay":false,"video_controls":true,"video_muted":false,"video_loop":false,"gallery_images":[],"gallery_layout":"grid","gallery_columns":3,"list_type":"unordered","list_items":[],"container_max_width":"1200px","container_align":"center","animation_type":"none","animation_duration":"0.3s","animation_delay":"0s","seo_title":"","seo_description":"","seo_keywords":[],"aria_label":"","aria_description":"","tab_index":0}},{"id":"d1797716-cf47-4b18-95f8-b00de1062ccb","component_type":"Heading","content":"# Modern Content Management","styles":{"background_color":"transparent","text_color":"inherit","padding":"16px","margin":"8px","border_radius":"8px","font_size":"16px","font_weight":"normal","text_align":"left","border_width":"0px","border_color":"transparent","border_style":"solid","box_shadow":"none","opacity":1.0,"z_index":1,"font_family":"system-ui, -apple-system, sans-serif","line_height":"1.5","letter_spacing":"normal","text_decoration":"none","text_transform":"none","background_image":"none","background_size":"cover","background_position":"center","background_repeat":"no-repeat"},"position":{"x":0.0,"y":0.0,"width":"100%","height":"auto"},"properties":{"image_url":"","image_alt":"","image_title":"","image_lazy_load":true,"button_text":"Click Here","button_url":"#","button_target":"_self","button_size":"medium","button_variant":"primary","button_icon":"","form_action":"","form_method":"POST","form_fields":[],"video_url":"","video_autoplay":false,"video_controls":true,"video_muted":false,"video_loop":false,"gallery_images":[],"gallery_layout":"grid","gallery_columns":3,"list_type":"unordered","list_items":[],"container_max_width":"1200px","container_align":"center","animation_type":"none","animation_duration":"0.3s","animation_delay":"0s","seo_title":"","seo_description":"","seo_keywords":[],"aria_label":"","aria_description":"","tab_index":0}}]	2	2025-08-01 16:48:30.713325	2025-08-01 16:53:38.465939	extraordinary	published
25	rocket	[{"id":"6e56db71-9a0f-4864-8f0f-47905c5d45ad","component_type":"Button","content":"[Start Building 🚀](/page-builder)","styles":{"background_color":"transparent","text_color":"inherit","padding":"16px","margin":"8px","border_radius":"8px","font_size":"16px","font_weight":"normal","text_align":"left","border_width":"0px","border_color":"transparent","border_style":"solid","box_shadow":"none","opacity":1.0,"z_index":1,"font_family":"system-ui, -apple-system, sans-serif","line_height":"1.5","letter_spacing":"normal","text_decoration":"none","text_transform":"none","background_image":"none","background_size":"cover","background_position":"center","background_repeat":"no-repeat"},"position":{"x":0.0,"y":0.0,"width":"100%","height":"auto"},"properties":{"image_url":"","image_alt":"","image_title":"","image_lazy_load":true,"button_text":"Click Here","button_url":"#","button_target":"_self","button_size":"medium","button_variant":"primary","button_icon":"","form_action":"","form_method":"POST","form_fields":[],"video_url":"","video_autoplay":false,"video_controls":true,"video_muted":false,"video_loop":false,"gallery_images":[],"gallery_layout":"grid","gallery_columns":3,"list_type":"unordered","list_items":[],"container_max_width":"1200px","container_align":"center","animation_type":"none","animation_duration":"0.3s","animation_delay":"0s","seo_title":"","seo_description":"","seo_keywords":[],"aria_label":"","aria_description":"","tab_index":0}},{"id":"35d4ccc2-b459-498e-b13b-063102e2d2b5","component_type":"Text","content":"Welcome to our comprehensive content management system built with Rust and modern web technologies. This platform provides powerful tools for creating, managing, and publishing content with ease.","styles":{"background_color":"transparent","text_color":"inherit","padding":"16px","margin":"8px","border_radius":"8px","font_size":"16px","font_weight":"normal","text_align":"left","border_width":"0px","border_color":"transparent","border_style":"solid","box_shadow":"none","opacity":1.0,"z_index":1,"font_family":"system-ui, -apple-system, sans-serif","line_height":"1.5","letter_spacing":"normal","text_decoration":"none","text_transform":"none","background_image":"none","background_size":"cover","background_position":"center","background_repeat":"no-repeat"},"position":{"x":0.0,"y":0.0,"width":"100%","height":"auto"},"properties":{"image_url":"","image_alt":"","image_title":"","image_lazy_load":true,"button_text":"Click Here","button_url":"#","button_target":"_self","button_size":"medium","button_variant":"primary","button_icon":"","form_action":"","form_method":"POST","form_fields":[],"video_url":"","video_autoplay":false,"video_controls":true,"video_muted":false,"video_loop":false,"gallery_images":[],"gallery_layout":"grid","gallery_columns":3,"list_type":"unordered","list_items":[],"container_max_width":"1200px","container_align":"center","animation_type":"none","animation_duration":"0.3s","animation_delay":"0s","seo_title":"","seo_description":"","seo_keywords":[],"aria_label":"","aria_description":"","tab_index":0}},{"id":"f5cd671f-04e5-4d0a-9a86-f9f3e1f9679c","component_type":"ThreeColumn","content":"## ⚡ Fast\\n\\nRust-powered backend delivers exceptional performance\\n\\n## 🔒 Secure\\n\\nBuilt-in security features and best practices\\n\\n## 🎯 Flexible\\n\\nCustomizable components and layouts","styles":{"background_color":"transparent","text_color":"inherit","padding":"16px","margin":"8px","border_radius":"8px","font_size":"16px","font_weight":"normal","text_align":"left","border_width":"0px","border_color":"transparent","border_style":"solid","box_shadow":"none","opacity":1.0,"z_index":1,"font_family":"system-ui, -apple-system, sans-serif","line_height":"1.5","letter_spacing":"normal","text_decoration":"none","text_transform":"none","background_image":"none","background_size":"cover","background_position":"center","background_repeat":"no-repeat"},"position":{"x":0.0,"y":0.0,"width":"100%","height":"auto"},"properties":{"image_url":"","image_alt":"","image_title":"","image_lazy_load":true,"button_text":"Click Here","button_url":"#","button_target":"_self","button_size":"medium","button_variant":"primary","button_icon":"","form_action":"","form_method":"POST","form_fields":[],"video_url":"","video_autoplay":false,"video_controls":true,"video_muted":false,"video_loop":false,"gallery_images":[],"gallery_layout":"grid","gallery_columns":3,"list_type":"unordered","list_items":[],"container_max_width":"1200px","container_align":"center","animation_type":"none","animation_duration":"0.3s","animation_delay":"0s","seo_title":"","seo_description":"","seo_keywords":[],"aria_label":"","aria_description":"","tab_index":0}}]	2	2025-08-01 18:38:35.32902	\N	rocket	published
32	Home	[{"id":"64d0442a-bcb9-4baf-8af6-4ed8396374e4","component_type":"Heading","content":"# Modern Content Management","styles":{"background_color":"transparent","text_color":"var(--public-text-primary, #000000)","padding":"16px","margin":"8px","border_radius":"8px","font_size":"16px","font_weight":"normal","text_align":"left","border_width":"0px","border_color":"transparent","border_style":"solid","box_shadow":"none","opacity":1.0,"z_index":1,"font_family":"system-ui, -apple-system, sans-serif","line_height":"1.5","letter_spacing":"normal","text_decoration":"none","text_transform":"none","background_image":"none","background_size":"cover","background_position":"center","background_repeat":"no-repeat"},"position":{"x":0.0,"y":0.0,"width":"100%","height":"auto"},"properties":{"image_url":"","image_alt":"","image_title":"","image_lazy_load":true,"button_text":"Click Here","button_url":"#","button_target":"_self","button_size":"medium","button_variant":"primary","button_icon":"","form_action":"","form_method":"POST","form_fields":[],"video_url":"","video_autoplay":false,"video_controls":true,"video_muted":false,"video_loop":false,"gallery_images":[],"gallery_layout":"grid","gallery_columns":3,"list_type":"unordered","list_items":[],"container_max_width":"1200px","container_align":"center","animation_type":"none","animation_duration":"0.3s","animation_delay":"0s","seo_title":"","seo_description":"","seo_keywords":[],"aria_label":"","aria_description":"","tab_index":0}},{"id":"af2832b6-d51d-4cb8-b622-c270e90ecf00","component_type":"PostsList","content":"## 📄 Latest Posts\\n\\nDiscover our latest articles and insights. This dynamic list automatically displays your most recent blog posts.\\n\\n[This will show a list of your published posts]","styles":{"background_color":"transparent","text_color":"var(--public-text-primary, #000000)","padding":"16px","margin":"8px","border_radius":"8px","font_size":"16px","font_weight":"normal","text_align":"left","border_width":"0px","border_color":"transparent","border_style":"solid","box_shadow":"none","opacity":1.0,"z_index":1,"font_family":"system-ui, -apple-system, sans-serif","line_height":"1.5","letter_spacing":"normal","text_decoration":"none","text_transform":"none","background_image":"none","background_size":"cover","background_position":"center","background_repeat":"no-repeat"},"position":{"x":0.0,"y":0.0,"width":"100%","height":"auto"},"properties":{"image_url":"","image_alt":"","image_title":"","image_lazy_load":true,"button_text":"Click Here","button_url":"#","button_target":"_self","button_size":"medium","button_variant":"primary","button_icon":"","form_action":"","form_method":"POST","form_fields":[],"video_url":"","video_autoplay":false,"video_controls":true,"video_muted":false,"video_loop":false,"gallery_images":[],"gallery_layout":"grid","gallery_columns":3,"list_type":"unordered","list_items":[],"container_max_width":"1200px","container_align":"center","animation_type":"none","animation_duration":"0.3s","animation_delay":"0s","seo_title":"","seo_description":"","seo_keywords":[],"aria_label":"","aria_description":"","tab_index":0}}]	2	2025-08-02 14:32:20.631824	2025-08-02 22:56:08.569991	home	published
33	Posts	[{"id":"782870f5-4e91-4faf-b585-f1fba805cdf5","component_type":"PostsList","content":"## 📄 Latest Posts\\n\\nDiscover our latest articles and insights. This dynamic list automatically displays your most recent blog posts.\\n\\n[This will show a list of your published posts]","styles":{"background_color":"transparent","text_color":"inherit","padding":"16px","margin":"8px","border_radius":"8px","font_size":"16px","font_weight":"normal","text_align":"left","border_width":"0px","border_color":"transparent","border_style":"solid","box_shadow":"none","opacity":1.0,"z_index":1,"font_family":"system-ui, -apple-system, sans-serif","line_height":"1.5","letter_spacing":"normal","text_decoration":"none","text_transform":"none","background_image":"none","background_size":"cover","background_position":"center","background_repeat":"no-repeat"},"position":{"x":0.0,"y":0.0,"width":"100%","height":"auto"},"properties":{"image_url":"","image_alt":"","image_title":"","image_lazy_load":true,"button_text":"Click Here","button_url":"#","button_target":"_self","button_size":"medium","button_variant":"primary","button_icon":"","form_action":"","form_method":"POST","form_fields":[],"video_url":"","video_autoplay":false,"video_controls":true,"video_muted":false,"video_loop":false,"gallery_images":[],"gallery_layout":"grid","gallery_columns":3,"list_type":"unordered","list_items":[],"container_max_width":"1200px","container_align":"center","animation_type":"none","animation_duration":"0.3s","animation_delay":"0s","seo_title":"","seo_description":"","seo_keywords":[],"aria_label":"","aria_description":"","tab_index":0}},{"id":"daffaf2d-b1a0-4ce6-8fb1-20e97c613165","component_type":"Text","content":"Welcome to our comprehensive content management system built with Rust and modern web technologies. This platform provides powerful tools for creating, managing, and publishing content with ease.","styles":{"background_color":"transparent","text_color":"var(--public-text-primary, #000000)","padding":"16px","margin":"8px","border_radius":"8px","font_size":"16px","font_weight":"normal","text_align":"left","border_width":"0px","border_color":"transparent","border_style":"solid","box_shadow":"none","opacity":1.0,"z_index":1,"font_family":"system-ui, -apple-system, sans-serif","line_height":"1.5","letter_spacing":"normal","text_decoration":"none","text_transform":"none","background_image":"none","background_size":"cover","background_position":"center","background_repeat":"no-repeat"},"position":{"x":0.0,"y":0.0,"width":"100%","height":"auto"},"properties":{"image_url":"","image_alt":"","image_title":"","image_lazy_load":true,"button_text":"Click Here","button_url":"#","button_target":"_self","button_size":"medium","button_variant":"primary","button_icon":"","form_action":"","form_method":"POST","form_fields":[],"video_url":"","video_autoplay":false,"video_controls":true,"video_muted":false,"video_loop":false,"gallery_images":[],"gallery_layout":"grid","gallery_columns":3,"list_type":"unordered","list_items":[],"container_max_width":"1200px","container_align":"center","animation_type":"none","animation_duration":"0.3s","animation_delay":"0s","seo_title":"","seo_description":"","seo_keywords":[],"aria_label":"","aria_description":"","tab_index":0}},{"id":"37849545-7892-4bd5-b3de-99b603eb3a34","component_type":"Card","content":"## 🌟 Feature Highlight\\n\\nDrag-and-drop page builder with real-time preview. Create professional pages without coding knowledge.\\n\\n**Key Benefits:**\\n- Visual editing\\n- Real-time preview\\n- Mobile responsive\\n- SEO optimized\\n\\n[Try Page Builder →](/page-builder)","styles":{"background_color":"transparent","text_color":"var(--public-text-primary, #000000)","padding":"16px","margin":"8px","border_radius":"8px","font_size":"16px","font_weight":"normal","text_align":"left","border_width":"0px","border_color":"transparent","border_style":"solid","box_shadow":"none","opacity":1.0,"z_index":1,"font_family":"system-ui, -apple-system, sans-serif","line_height":"1.5","letter_spacing":"normal","text_decoration":"none","text_transform":"none","background_image":"none","background_size":"cover","background_position":"center","background_repeat":"no-repeat"},"position":{"x":0.0,"y":0.0,"width":"100%","height":"auto"},"properties":{"image_url":"","image_alt":"","image_title":"","image_lazy_load":true,"button_text":"Click Here","button_url":"#","button_target":"_self","button_size":"medium","button_variant":"primary","button_icon":"","form_action":"","form_method":"POST","form_fields":[],"video_url":"","video_autoplay":false,"video_controls":true,"video_muted":false,"video_loop":false,"gallery_images":[],"gallery_layout":"grid","gallery_columns":3,"list_type":"unordered","list_items":[],"container_max_width":"1200px","container_align":"center","animation_type":"none","animation_duration":"0.3s","animation_delay":"0s","seo_title":"","seo_description":"","seo_keywords":[],"aria_label":"","aria_description":"","tab_index":0}},{"id":"fab4743f-e881-46f7-b026-3838a3f1ac87","component_type":"List","content":"✅ **Rust-powered backend** for maximum performance\\n✅ **WebAssembly frontend** for modern user experience\\n✅ **Drag-and-drop page builder** for easy content creation\\n✅ **Media management** with file upload and organization\\n✅ **User authentication** and role-based access\\n✅ **Responsive design** that works on all devices","styles":{"background_color":"transparent","text_color":"var(--public-text-primary, #000000)","padding":"16px","margin":"8px","border_radius":"8px","font_size":"16px","font_weight":"normal","text_align":"left","border_width":"0px","border_color":"transparent","border_style":"solid","box_shadow":"none","opacity":1.0,"z_index":1,"font_family":"system-ui, -apple-system, sans-serif","line_height":"1.5","letter_spacing":"normal","text_decoration":"none","text_transform":"none","background_image":"none","background_size":"cover","background_position":"center","background_repeat":"no-repeat"},"position":{"x":0.0,"y":0.0,"width":"100%","height":"auto"},"properties":{"image_url":"","image_alt":"","image_title":"","image_lazy_load":true,"button_text":"Click Here","button_url":"#","button_target":"_self","button_size":"medium","button_variant":"primary","button_icon":"","form_action":"","form_method":"POST","form_fields":[],"video_url":"","video_autoplay":false,"video_controls":true,"video_muted":false,"video_loop":false,"gallery_images":[],"gallery_layout":"grid","gallery_columns":3,"list_type":"unordered","list_items":[],"container_max_width":"1200px","container_align":"center","animation_type":"none","animation_duration":"0.3s","animation_delay":"0s","seo_title":"","seo_description":"","seo_keywords":[],"aria_label":"","aria_description":"","tab_index":0}},{"id":"3378ab73-95f8-4c4d-8c4f-f0689deb8a38","component_type":"Text","content":"Welcome to our comprehensive content management system built with Rust and modern web technologies. This platform provides powerful tools for creating, managing, and publishing content with ease.","styles":{"background_color":"transparent","text_color":"var(--public-text-primary, #000000)","padding":"16px","margin":"8px","border_radius":"8px","font_size":"16px","font_weight":"normal","text_align":"left","border_width":"0px","border_color":"transparent","border_style":"solid","box_shadow":"none","opacity":1.0,"z_index":1,"font_family":"system-ui, -apple-system, sans-serif","line_height":"1.5","letter_spacing":"normal","text_decoration":"none","text_transform":"none","background_image":"none","background_size":"cover","background_position":"center","background_repeat":"no-repeat"},"position":{"x":0.0,"y":0.0,"width":"100%","height":"auto"},"properties":{"image_url":"","image_alt":"","image_title":"","image_lazy_load":true,"button_text":"Click Here","button_url":"#","button_target":"_self","button_size":"medium","button_variant":"primary","button_icon":"","form_action":"","form_method":"POST","form_fields":[],"video_url":"","video_autoplay":false,"video_controls":true,"video_muted":false,"video_loop":false,"gallery_images":[],"gallery_layout":"grid","gallery_columns":3,"list_type":"unordered","list_items":[],"container_max_width":"1200px","container_align":"center","animation_type":"none","animation_duration":"0.3s","animation_delay":"0s","seo_title":"","seo_description":"","seo_keywords":[],"aria_label":"","aria_description":"","tab_index":0}},{"id":"0507507e-981d-42b0-bc9e-c9450c4cdb54","component_type":"Text","content":"Welcome to our comprehensive content management system built with Rust and modern web technologies. This platform provides powerful tools for creating, managing, and publishing content with ease.","styles":{"background_color":"transparent","text_color":"var(--public-text-primary, #000000)","padding":"16px","margin":"8px","border_radius":"8px","font_size":"16px","font_weight":"normal","text_align":"left","border_width":"0px","border_color":"transparent","border_style":"solid","box_shadow":"none","opacity":1.0,"z_index":1,"font_family":"system-ui, -apple-system, sans-serif","line_height":"1.5","letter_spacing":"normal","text_decoration":"none","text_transform":"none","background_image":"none","background_size":"cover","background_position":"center","background_repeat":"no-repeat"},"position":{"x":0.0,"y":0.0,"width":"100%","height":"auto"},"properties":{"image_url":"","image_alt":"","image_title":"","image_lazy_load":true,"button_text":"Click Here","button_url":"#","button_target":"_self","button_size":"medium","button_variant":"primary","button_icon":"","form_action":"","form_method":"POST","form_fields":[],"video_url":"","video_autoplay":false,"video_controls":true,"video_muted":false,"video_loop":false,"gallery_images":[],"gallery_layout":"grid","gallery_columns":3,"list_type":"unordered","list_items":[],"container_max_width":"1200px","container_align":"center","animation_type":"none","animation_duration":"0.3s","animation_delay":"0s","seo_title":"","seo_description":"","seo_keywords":[],"aria_label":"","aria_description":"","tab_index":0}}]	2	2025-08-02 14:32:28.920665	2025-08-02 22:20:15.535356	posts	published
\.


--
-- TOC entry 3863 (class 0 OID 24670)
-- Dependencies: 216
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: riverwalkit
--

COPY public.posts (id, title, content, category_id, user_id, created_at, updated_at) FROM stdin;
18	🚀 Welcome to the Future of Content Management	# Welcome to the Future of Content Management\n\nExperience the power of Rust-based CMS with WebAssembly frontend. Create stunning websites with our drag-and-drop page builder and comprehensive content management tools.\n\n## 🌟 Key Features\n\n✅ **Rust-powered backend** for maximum performance\n✅ **WebAssembly frontend** for modern user experience  \n✅ **Drag-and-drop page builder** for easy content creation\n✅ **Media management** with file upload and organization\n✅ **User authentication** and role-based access\n✅ **Responsive design** that works on all devices\n\n## 🚀 Performance First\n\nBuilt with Rust for maximum performance and reliability. Our backend delivers lightning-fast responses and handles high traffic with ease.\n\n> "This Rust CMS has revolutionized how we manage our content. The performance is incredible and the page builder makes it easy for our team to create beautiful pages without technical knowledge."\n> \n> *— Sarah Johnson, Content Manager*\n\n[Get Started →](/page-builder)	\N	2	2025-08-01 02:59:30.865809	\N
19	🎨 Building Beautiful Pages with Components	# Building Beautiful Pages with Components\n\nOur drag-and-drop page builder comes with a comprehensive set of components designed to help you create professional pages without any coding knowledge.\n\n## 📦 Available Components\n\n### Layout Components\n- **Hero Sections** - Create stunning landing page headers\n- **Two Column** - Perfect for feature comparisons\n- **Three Column** - Great for showcasing benefits\n- **Cards** - Highlight key information\n- **Containers** - Organize your content\n\n### Content Components  \n- **Text Blocks** - Rich text with markdown support\n- **Headings & Subheadings** - Structure your content\n- **Lists** - Organize information clearly\n- **Quotes** - Add social proof and testimonials\n- **Dividers** - Separate content sections\n\n### Interactive Components\n- **Buttons** - Call-to-action elements\n- **Links** - Navigation and references\n- **Contact Forms** - Get in touch with visitors\n- **Newsletter Signup** - Build your email list\n\n### Media Components\n- **Images** - Visual content support\n- **Videos** - Embed multimedia content\n- **Galleries** - Showcase multiple images\n- **Maps** - Show your location\n\n## 💡 Pro Tips\n\n1. **Start with a Hero** - Grab attention immediately\n2. **Use Three Columns** - Perfect for features/benefits\n3. **Add Social Proof** - Use quote components for testimonials\n4. **Include CTAs** - Guide users with button components\n5. **Mobile First** - All components are responsive\n\n[Try the Page Builder →](/admin)	\N	2	2025-08-01 02:59:39.002229	\N
20	🔧 Technical Deep Dive: Rust + WebAssembly	# Technical Deep Dive: Rust + WebAssembly\n\nLet's explore the technical architecture that makes our CMS so powerful and performant.\n\n## 🦀 Why Rust for the Backend?\n\nRust provides several key advantages for web applications:\n\n### Memory Safety\n- **Zero-cost abstractions** - No runtime overhead\n- **No garbage collector** - Predictable performance\n- **Thread safety** - Fearless concurrency\n- **No null pointer dereferences** - Eliminates entire classes of bugs\n\n### Performance Benefits\n- **Native code compilation** - As fast as C/C++\n- **Minimal runtime** - Low resource usage\n- **Excellent HTTP performance** - With Axum framework\n- **Database efficiency** - Using Diesel ORM\n\n## 🌐 WebAssembly Frontend\n\nOur frontend leverages WebAssembly for exceptional user experience:\n\n### Key Technologies\n- **Yew Framework** - React-like components in Rust\n- **WebAssembly** - Near-native performance in the browser\n- **Component-based architecture** - Reusable UI components\n- **Type safety** - Compile-time error checking\n\n### Performance Advantages\n```\nJavaScript: ~50-100ms rendering\nWebAssembly: ~5-10ms rendering\n```\n\n## 🏗️ Architecture Overview\n\n### Backend Stack\n- **Axum** - Fast, ergonomic web framework\n- **Diesel** - Safe, extensible ORM\n- **PostgreSQL** - Robust relational database\n- **bcrypt** - Secure password hashing\n- **Tower** - Modular service framework\n\n### Frontend Stack\n- **Yew** - Modern Rust framework for WebAssembly\n- **trunk** - Asset bundling and dev server\n- **gloo** - Modular toolkit for Rust/Wasm\n- **serde** - Serialization framework\n\n## 📊 Performance Metrics\n\n| Metric | Traditional CMS | Our Rust CMS |\n|--------|----------------|---------------|\n| Page Load Time | 2-5 seconds | 0.5-1 second |\n| Memory Usage | 200-500MB | 50-100MB |\n| Concurrent Users | 100-500 | 1000-5000 |\n| Security Vulnerabilities | Common | Minimal |\n\n## 🚀 Getting Started\n\nReady to experience the future of web development?\n\n1. **Clone the repository**\n2. **Set up PostgreSQL database**  \n3. **Run cargo for backend**\n4. **Run trunk serve for frontend**\n5. **Start building!**\n\n[View Source Code →](https://github.com/your-repo/rust-cms)	\N	2	2025-08-01 02:59:59.170682	\N
17	Test Post	This is a test post	\N	2	2025-08-01 00:47:04.274732	2025-08-02 18:55:50.629846
16	Test Post	This is a test	\N	2	2025-08-01 00:38:35.71608	2025-08-02 20:30:31.757327
\.


--
-- TOC entry 3877 (class 0 OID 24780)
-- Dependencies: 230
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: riverwalkit
--

COPY public.sessions (id, user_id, session_token, created_at, expires_at) FROM stdin;
134	2	1ed04692-08c5-48b1-8f64-cc055f62376f	2025-08-03 17:03:16.389763	2025-08-04 17:03:16.389594
135	2	c5889b8a-c6ad-4eb5-9c2d-08607486e597	2025-08-03 17:13:12.988397	2025-08-04 17:13:12.988336
136	2	48b628e3-fd79-4fd5-831f-9e6896179396	2025-08-03 17:28:49.406609	2025-08-04 17:28:49.406511
\.


--
-- TOC entry 3873 (class 0 OID 24748)
-- Dependencies: 226
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: riverwalkit
--

COPY public.settings (id, setting_key, setting_value, created_at, setting_type, description, updated_at) FROM stdin;
\.


--
-- TOC entry 3869 (class 0 OID 24721)
-- Dependencies: 222
-- Data for Name: templates; Type: TABLE DATA; Schema: public; Owner: riverwalkit
--

COPY public.templates (id, name, layout, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 3859 (class 0 OID 24577)
-- Dependencies: 212
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: riverwalkit
--

COPY public.users (id, username, password, email, created_at, role, status) FROM stdin;
2	admin	$2b$12$V1FW850b0gKwQs77gc9tDe.CyTEeh.iGoQ640hAyvVK.FXJLZI6um	admin@example.com	2025-07-31 15:29:46.768478	admin	active
\.


--
-- TOC entry 3914 (class 0 OID 0)
-- Dependencies: 223
-- Name: builder_components_id_seq; Type: SEQUENCE SET; Schema: public; Owner: riverwalkit
--

SELECT pg_catalog.setval('public.builder_components_id_seq', 1, false);


--
-- TOC entry 3915 (class 0 OID 0)
-- Dependencies: 213
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: riverwalkit
--

SELECT pg_catalog.setval('public.categories_id_seq', 1, true);


--
-- TOC entry 3916 (class 0 OID 0)
-- Dependencies: 227
-- Name: comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: riverwalkit
--

SELECT pg_catalog.setval('public.comments_id_seq', 1, false);


--
-- TOC entry 3917 (class 0 OID 0)
-- Dependencies: 239
-- Name: component_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: riverwalkit
--

SELECT pg_catalog.setval('public.component_events_id_seq', 1, false);


--
-- TOC entry 3918 (class 0 OID 0)
-- Dependencies: 237
-- Name: component_styles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: riverwalkit
--

SELECT pg_catalog.setval('public.component_styles_id_seq', 1, false);


--
-- TOC entry 3919 (class 0 OID 0)
-- Dependencies: 233
-- Name: components_id_seq; Type: SEQUENCE SET; Schema: public; Owner: riverwalkit
--

SELECT pg_catalog.setval('public.components_id_seq', 1, false);


--
-- TOC entry 3920 (class 0 OID 0)
-- Dependencies: 219
-- Name: media_id_seq; Type: SEQUENCE SET; Schema: public; Owner: riverwalkit
--

SELECT pg_catalog.setval('public.media_id_seq', 9, true);


--
-- TOC entry 3921 (class 0 OID 0)
-- Dependencies: 241
-- Name: navigation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: username
--

SELECT pg_catalog.setval('public.navigation_id_seq', 2, true);


--
-- TOC entry 3922 (class 0 OID 0)
-- Dependencies: 235
-- Name: page_components_id_seq; Type: SEQUENCE SET; Schema: public; Owner: riverwalkit
--

SELECT pg_catalog.setval('public.page_components_id_seq', 1, false);


--
-- TOC entry 3923 (class 0 OID 0)
-- Dependencies: 231
-- Name: page_sections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: riverwalkit
--

SELECT pg_catalog.setval('public.page_sections_id_seq', 1, false);


--
-- TOC entry 3924 (class 0 OID 0)
-- Dependencies: 217
-- Name: pages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: riverwalkit
--

SELECT pg_catalog.setval('public.pages_id_seq', 34, true);


--
-- TOC entry 3925 (class 0 OID 0)
-- Dependencies: 215
-- Name: posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: riverwalkit
--

SELECT pg_catalog.setval('public.posts_id_seq', 20, true);


--
-- TOC entry 3926 (class 0 OID 0)
-- Dependencies: 229
-- Name: sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: riverwalkit
--

SELECT pg_catalog.setval('public.sessions_id_seq', 136, true);


--
-- TOC entry 3927 (class 0 OID 0)
-- Dependencies: 225
-- Name: settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: riverwalkit
--

SELECT pg_catalog.setval('public.settings_id_seq', 1, false);


--
-- TOC entry 3928 (class 0 OID 0)
-- Dependencies: 221
-- Name: templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: riverwalkit
--

SELECT pg_catalog.setval('public.templates_id_seq', 1, false);


--
-- TOC entry 3929 (class 0 OID 0)
-- Dependencies: 211
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: riverwalkit
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- TOC entry 3657 (class 2606 OID 16391)
-- Name: __diesel_schema_migrations __diesel_schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.__diesel_schema_migrations
    ADD CONSTRAINT __diesel_schema_migrations_pkey PRIMARY KEY (version);


--
-- TOC entry 3678 (class 2606 OID 24741)
-- Name: builder_components builder_components_pkey; Type: CONSTRAINT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.builder_components
    ADD CONSTRAINT builder_components_pkey PRIMARY KEY (id);


--
-- TOC entry 3665 (class 2606 OID 24668)
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- TOC entry 3686 (class 2606 OID 24768)
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (id);


--
-- TOC entry 3700 (class 2606 OID 24868)
-- Name: component_events component_events_pkey; Type: CONSTRAINT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.component_events
    ADD CONSTRAINT component_events_pkey PRIMARY KEY (id);


--
-- TOC entry 3698 (class 2606 OID 24853)
-- Name: component_styles component_styles_pkey; Type: CONSTRAINT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.component_styles
    ADD CONSTRAINT component_styles_pkey PRIMARY KEY (id);


--
-- TOC entry 3694 (class 2606 OID 24820)
-- Name: components components_pkey; Type: CONSTRAINT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.components
    ADD CONSTRAINT components_pkey PRIMARY KEY (id);


--
-- TOC entry 3672 (class 2606 OID 24713)
-- Name: media media_pkey; Type: CONSTRAINT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_pkey PRIMARY KEY (id);


--
-- TOC entry 3703 (class 2606 OID 25184)
-- Name: navigation navigation_pkey; Type: CONSTRAINT; Schema: public; Owner: username
--

ALTER TABLE ONLY public.navigation
    ADD CONSTRAINT navigation_pkey PRIMARY KEY (id);


--
-- TOC entry 3696 (class 2606 OID 24833)
-- Name: page_components page_components_pkey; Type: CONSTRAINT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.page_components
    ADD CONSTRAINT page_components_pkey PRIMARY KEY (id);


--
-- TOC entry 3692 (class 2606 OID 24805)
-- Name: page_sections page_sections_pkey; Type: CONSTRAINT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.page_sections
    ADD CONSTRAINT page_sections_pkey PRIMARY KEY (id);


--
-- TOC entry 3669 (class 2606 OID 24698)
-- Name: pages pages_pkey; Type: CONSTRAINT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_pkey PRIMARY KEY (id);


--
-- TOC entry 3667 (class 2606 OID 24678)
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- TOC entry 3688 (class 2606 OID 24788)
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- TOC entry 3690 (class 2606 OID 24790)
-- Name: sessions sessions_session_token_key; Type: CONSTRAINT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_session_token_key UNIQUE (session_token);


--
-- TOC entry 3682 (class 2606 OID 24756)
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- TOC entry 3684 (class 2606 OID 24758)
-- Name: settings settings_setting_key_key; Type: CONSTRAINT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_setting_key_key UNIQUE (setting_key);


--
-- TOC entry 3674 (class 2606 OID 24731)
-- Name: templates templates_name_key; Type: CONSTRAINT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.templates
    ADD CONSTRAINT templates_name_key UNIQUE (name);


--
-- TOC entry 3676 (class 2606 OID 24729)
-- Name: templates templates_pkey; Type: CONSTRAINT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.templates
    ADD CONSTRAINT templates_pkey PRIMARY KEY (id);


--
-- TOC entry 3659 (class 2606 OID 24589)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 3661 (class 2606 OID 24585)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 3663 (class 2606 OID 24587)
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- TOC entry 3701 (class 1259 OID 25185)
-- Name: idx_navigation_order; Type: INDEX; Schema: public; Owner: username
--

CREATE INDEX idx_navigation_order ON public.navigation USING btree (order_position);


--
-- TOC entry 3679 (class 1259 OID 25192)
-- Name: idx_settings_key; Type: INDEX; Schema: public; Owner: riverwalkit
--

CREATE INDEX idx_settings_key ON public.settings USING btree (setting_key);


--
-- TOC entry 3680 (class 1259 OID 25191)
-- Name: idx_settings_type; Type: INDEX; Schema: public; Owner: riverwalkit
--

CREATE INDEX idx_settings_type ON public.settings USING btree (setting_type);


--
-- TOC entry 3670 (class 1259 OID 25187)
-- Name: pages_slug_idx; Type: INDEX; Schema: public; Owner: riverwalkit
--

CREATE UNIQUE INDEX pages_slug_idx ON public.pages USING btree (slug);


--
-- TOC entry 3708 (class 2606 OID 24742)
-- Name: builder_components builder_components_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.builder_components
    ADD CONSTRAINT builder_components_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.templates(id);


--
-- TOC entry 3709 (class 2606 OID 24769)
-- Name: comments comments_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.posts(id);


--
-- TOC entry 3710 (class 2606 OID 24774)
-- Name: comments comments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 3717 (class 2606 OID 24869)
-- Name: component_events component_events_component_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.component_events
    ADD CONSTRAINT component_events_component_id_fkey FOREIGN KEY (component_id) REFERENCES public.components(id);


--
-- TOC entry 3716 (class 2606 OID 24854)
-- Name: component_styles component_styles_component_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.component_styles
    ADD CONSTRAINT component_styles_component_id_fkey FOREIGN KEY (component_id) REFERENCES public.components(id);


--
-- TOC entry 3713 (class 2606 OID 24821)
-- Name: components components_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.components
    ADD CONSTRAINT components_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.templates(id);


--
-- TOC entry 3707 (class 2606 OID 24714)
-- Name: media media_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 3715 (class 2606 OID 24839)
-- Name: page_components page_components_component_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.page_components
    ADD CONSTRAINT page_components_component_id_fkey FOREIGN KEY (component_id) REFERENCES public.components(id);


--
-- TOC entry 3714 (class 2606 OID 24834)
-- Name: page_components page_components_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.page_components
    ADD CONSTRAINT page_components_page_id_fkey FOREIGN KEY (page_id) REFERENCES public.pages(id);


--
-- TOC entry 3712 (class 2606 OID 24806)
-- Name: page_sections page_sections_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.page_sections
    ADD CONSTRAINT page_sections_page_id_fkey FOREIGN KEY (page_id) REFERENCES public.pages(id);


--
-- TOC entry 3706 (class 2606 OID 24699)
-- Name: pages pages_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 3704 (class 2606 OID 24679)
-- Name: posts posts_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- TOC entry 3705 (class 2606 OID 24684)
-- Name: posts posts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 3711 (class 2606 OID 24791)
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: riverwalkit
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 3896 (class 0 OID 0)
-- Dependencies: 3895
-- Name: DATABASE my_rust_cms; Type: ACL; Schema: -; Owner: burtron
--

GRANT ALL ON DATABASE my_rust_cms TO riverwalkit;
GRANT ALL ON DATABASE my_rust_cms TO my_rust_cms_user;
GRANT ALL ON DATABASE my_rust_cms TO username;


-- Completed on 2025-08-03 13:46:29 EDT

--
-- PostgreSQL database dump complete
--

